package com.puput.projectrizqiputpitasari;

import java.util.ArrayList;

public class DataSkincare {
    private static String[] skincareNames = {
            "Loreal",
            "Nature Repubic",
            "Olay",
            "Senka Perfect Whip",
            "PONDS",
            "Safi",
            "Sun Protection",
            "Utama Spice Virgin Coconut Oil",
            "Viva",
            "Wardah"
    };

    private static String[] skincareDetails = {
            "L'Oreal merk ini punya krim pemutih dengan kandungan melanin lho. Formula ini lah yang katanya efektif banget untuk mencerahkan warna kulit wajah hingga 50 kali lebih hebat. ",
            "Nature Republic, Gel lidah buaya yang memiliki berbagai manfaat mulai dari ujung rambut hingga ujung kaki. berfungsi untuk melembutkan kulit",
            "Olay paham betul kalau selama kita tidur, tubuh kita paling optimal meregenerasi sel-sel kulit. Karena itu, mereka mengeluarkan produk whitening ini yang memang diformulasikan khusus untuk bekerja di malam hari.",
            "Senka Perfect Whip merupakan produk pembersih wajah asal Jepang yang tengah diminati banyak pecinta skin care di Indonesia. Di dalamnya terdapat kandungan White Cocoon Essence yang mampu menghasilkan busa lembut yang tebal dan juga padat. Busa inilah yang nantinya akan bekerja mengangkat sisa-sisa kotoran dan makeup yang menempel di kulit wajah. Meski intensitas busa yang dihasilkan sangat banyak, para pengguna tak perlu khawatir kulit akan menjadi kering karena produk pembersih wajah ini telah dilengkapi dengan Double Hyaluronic Acid yang mampu menjaga kelembapan serta membuat kulit senantiasa lembap. Menariknya lagi, produk berkemasan praktis ini juga tersedia dalam dua ukuran yang bisa Anda pilih sesuai kebutuhan, yakni 120 gram dan 40 gram..",
            "Pond's Tetap dengan GenActiv Formula, krim malam pemutih dari Pond's ini dapat menghilangkan kekusaman dari kulitmu.Biasanya, ini lah masalah terbesar yang dialami wanita dengan warna kulit yang cenderung gelap.",
            "Safi Krim siang dengan formula lembut yang mudah diserap kulit, mampu melindungi kulit dari paparan sinar UVA dan UVB. lembut di kulit dan menyegarkan",
            "Sun Protection Menjaga kulit dari sengatan sinar UV matahari.Jangan sampai kulitmu jadi belang karena tidak ada yang melindungi. Nah, salah satu produk dari Emina ini bisa banget untuk menjaga kulitmu dari sinar UV. Yap, sun protection dari Emina ini recommended banget deh buat menjaga kulitmu. Selain itu, sun protection dari Emina ini cocok untuk segala jenis kulit.",
            "Utama Spice Virgin Coconut Oil Produk ini mengandung anti-oksidan, vitamin E, dan asam lemak esensial yang baik untuk menjaga kesehatan dan keremajaan kulit. Selain itu, minyak alami ini juga berguna untuk merawat serta membuat tampilan rambut lebih berkilau. Menariknya lagi, proses pembuatan produk ini juga tanpa melalui pemanasan, sehingga kandungan nutrisinya tetap terjaga. Saking banyaknya manfaat yang dimiliki, tak heran jika hampir seluruh produk Utama Spice menggunakan kandungan minyak kelapa murni ini.",
            "Viva Krim yang menutrisi dan melembapkan kulit serta menjaga vitalitas kulit. Gunakan secara rutin untuk kulit tampak sehat dan lembut terawat..",
            "Wardah Merek kosmetik lokal ini menggunakan teknologi canggih terkini di bawah pengawasan ahli dan dokter kulit untuk menghasilkan produk-produk kecantikan yang berkualitas. Brand values yang diusung Wardah yaitu: pure and safe, beauty expert, dan inspiring beauty. Setiap produk-produk dan peralatan kecantikan Wardah telah memenuhi standar kesehatan dan aman untuk digunakan."
    };

    private static int[] skincareImages = {
            R.drawable.loreal,
            R.drawable.nature,
            R.drawable.ol,
            R.drawable.perfect,
            R.drawable.pond,
            R.drawable.savi,
            R.drawable.sunprotect,
            R.drawable.utama,
            R.drawable.viva,
            R.drawable.wardah
    };

    private static String[] skincareHarga={
            "Rp. 15.200 /pcs",
            "Rp. 50.000 /pcs",
            "Rp. 80.000 /pcs",
            "Rp. 30.000 /pcs",
            "Rp. 20.000 /pcs",
            "Rp. 50.000 /pcs",
            "Rp. 40.000 /pcs",
            "Rp. 30.000 /pcs",
            "Rp. 40.0000 /pcs",
            "Rp. 30.000 /pcs"
    };

    private static String[] skincareDeskripsi={
            "Mencerahkan kulit dan melembutkan.",
            "Pelembab kulit dan menghaluskan.",
            "Meremajakan kulit.",
            "Mencerahkan kulit mengandung Vitamin E",
            "Meremajakan kulit",
            "Menjaga kulit agar tetap segar sepanjang hari",
            "Menjaga kulit dari paparan sinar matahari",
            "Baik untuk menjaga kesehatan dan keremajaan kulit",
            "Meremajakan kulit dan menutup pori pori",
            "Mencerahkan kulit, dan meremajakan kulit."
    };

    static ArrayList<Skincare> getListData() {
        ArrayList<Skincare> list = new ArrayList<>();
        for (int position = 0; position < skincareNames.length; position++) {
            Skincare skincare = new Skincare();
            skincare.setNama(skincareNames[position]);
            skincare.setDeskripsi(skincareDetails[position]);
            skincare.setPhoto(skincareImages[position]);
            list.add(skincare);
        }
        return list;
    }

}
