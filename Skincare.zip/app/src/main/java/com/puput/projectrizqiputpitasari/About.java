package com.puput.projectrizqiputpitasari;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.puput.projectrizqiputpitasari.BaseMenu;
import com.puput.projectrizqiputpitasari.R;

public class About extends BaseMenu {

    TextView mActionBarToolbar;
    ImageView ivTopbar, image;
    TextView name, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        findViews();
        initListeners();
        comp();
    }

    @Override
    public void findViews(){
        mActionBarToolbar = findViewById(R.id.tv_item_topbar);
        ivTopbar = findViewById(R.id.iv_topbar);
        image = findViewById(R.id.photo_about);
        name = findViewById(R.id.tvnama);
        email = findViewById(R.id.tvemail);
    }

    @Override
    public void comp(){
        mActionBarToolbar.setText("About");
    }

    @Override
    public void initListeners(){
        ivTopbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    public void onBackPressed(){
        super.onBackPressed();
    }
}
