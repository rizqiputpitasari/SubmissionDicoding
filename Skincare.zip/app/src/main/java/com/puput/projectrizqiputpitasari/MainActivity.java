package com.puput.projectrizqiputpitasari;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.puput.projectrizqiputpitasari.DataSkincare;
import com.puput.projectrizqiputpitasari.Skincare;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvHost;
    private ArrayList<Skincare> list = new ArrayList<>();
    ImageView ivTopbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvHost = findViewById(R.id.rv_host);
        rvHost.setHasFixedSize(true);

        ivTopbar = findViewById(R.id.iv_topbar_main);
        ivTopbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent move = new Intent(MainActivity.this, About.class);
                startActivity(move);
            }
        });

        list.addAll(DataSkincare.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        rvHost.setLayoutManager(new LinearLayoutManager(this));
        SkincareAdapter hostAdapter = new SkincareAdapter(list);
        rvHost.setAdapter(hostAdapter);

        hostAdapter.setOnItemClickCallback(new SkincareAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Skincare data) {
                intentSelectHosting(data);
            }
        });
    }

    private void intentSelectHosting(Skincare host) {
        Intent move = new Intent(MainActivity.this, Deskripsi.class);
        move.putExtra("photo", host.getPhoto());
        move.putExtra("nama", host.getNama());
        move.putExtra("deskripsi", host.getDeskripsi());
        startActivity(move);
    }
}